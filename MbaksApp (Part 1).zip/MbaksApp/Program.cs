﻿namespace MbaksApp
{
    class Recipe

    {
        private string[] Ingredients;
        private double[] quantities;
        private string[] units;
        private string[] steps;

        public Recipe()
        {
            // Here you initialize empty arrays for ingredients, quantities, units and steps
            Ingredients = new string[0];
            quantities = new double[0];
            units = new string[0];
            steps = new string[0];
        }
        public void enterDetails()
        {
            //Ask the user to enter the number of ingredients
            Console.WriteLine("Enter the number of ingredients you wish to have");
            int ingredientsNum = int.Parse(Console.ReadLine());

            // here you initialize the arrays with the correct sizes
            Ingredients = new string[ingredientsNum];
            quantities = new double[ingredientsNum];
            units = new string[ingredientsNum];

            // Ask the user to enter the details for each ingredient
            for (int i = 0; i < ingredientsNum; i++)
            {
                Console.WriteLine($"Please enter the details for each ingredient #{1 + i}: ");
                Console.WriteLine("Name: ");
                Ingredients[i] = Console.ReadLine();
                Console.WriteLine("Quantity: ");
                quantities[i] = double.Parse(Console.ReadLine());
                Console.WriteLine("Units of Measurement: ");
                units[i] = Console.ReadLine();
            }
            //Ask the user to enter the number of steps for each ingredient
            Console.WriteLine("Enter the number of Steps:");
            int stepsNum = int.Parse(Console.ReadLine());

            //initializing the step array with the correct size
            steps = new string[stepsNum];

            //Ask the user to enter the description to for each step
            for (int i = 0; i < stepsNum; i++)
            {
                Console.WriteLine($"Enter your step #{1 + i}: ");
                steps[i] = Console.ReadLine();
            }
        }
        public void displayRecipe()
        {
            //display or show the ingredients and quantities
            Console.WriteLine("Ingredients: ");
            for (int i = 0; i < Ingredients.Length; i++)
            {
                Console.WriteLine($"- {quantities[i]} {units[i]} of {Ingredients[i]}");

            }
            //display or show the steps
            Console.WriteLine("Your Steps");
            for (int i = 0; i < steps.Length; i++)
            {
                Console.WriteLine($"- {steps[i]}: ");

            }
        }
        public void recipeScale(double factor)
        {
            //Multiply all the quantities with the scaling factor
            for (int i = 0; i < quantities.Length; i++)
            {
                quantities[i] *= factor;
            }
        }

        public void resetQuantities()
        {
            //ask the user if he or she would like to reset the values and let him or her reset them
            for (int i = 0; i < quantities.Length; i++)
            {
                quantities[i] /= 2;

            }
        }
        public void clearRecipe()
        {
            //give the user an option to reset the array to empty
            quantities = new double[0];
            Ingredients = new string[0];
            steps = new string[0];
            units = new string[0];
        }
    }
    class Program {
        static void main(string[] argss)
        {
            Recipe recipe = new Recipe();
            while (true)
            {
                Console.WriteLine("Enter 1 to enter recipe details");
                Console.WriteLine("Enter 2 to display recipe");
                Console.WriteLine("Enter 3 to scale recipe");
                Console.WriteLine("Enter 4 to reset quantities");
                Console.WriteLine("Enter 5 to clear recipe");
                Console.WriteLine("Enter 6 to exit");

                string Choice = Console.ReadLine();
                switch (Choice)
                {
                    case "1":
                        recipe.enterDetails();
                        break;

                    case "2":
                        recipe.displayRecipe();
                        break;

                    case "3":
                        Console.WriteLine("Enter your scaling factor (0.5, 2 or 3");
                        double factor = double.Parse(Console.ReadLine());
                        break;

                    case "4":
                        recipe.resetQuantities();
                            break;

                    case "5":
                        recipe.clearRecipe();
                        break;

                    case "6":
                        Console.WriteLine("Program exited");
                        return;
                    default:
                        Console.WriteLine("Invalid choice, please enter a valid choice");
                        break;
                }
            }
        }
    }
}